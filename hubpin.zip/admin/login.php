<!DOCTYPE html>
<html>
<head>
<title>FORM LOGIN ADMIN</title>
</head>
<center>
<h1>LOGIN ADMIN</h1>
<form method="POST" action="cek_login.php">
<table>
   <tr>
       <td>Username</td>
       <td> : <input type="username" name ="username"></td>
   </tr>
   <tr>
       <td>Password</td>
       <td> : <input type="password" name ="password"></td>
   </tr>
   <tr>
       <td align="center" colspan="2"><input type="submit" value="Login">
       </td>
	   	   <a href="../index.html">KEMBALI</a><br>
   </tr>
</table>
</form>
</center>
</body>
</html>